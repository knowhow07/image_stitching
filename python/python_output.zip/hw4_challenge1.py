#include <Eigen/Dense>
#include <vector>
#include <opencv2/opencv.hpp>

cv::Mat computeHomography(const std::vector<cv::Point2f>& src_pts, const std::vector<cv::Point2f>& dst_pts) {
    Eigen::MatrixXd A(8, 9);
    for (int i = 0, j = 0; i < 4; ++i, j += 2) {
        double x = src_pts[i].x;
        double y = src_pts[i].y;
        double u = dst_pts[i].x;
        double v = dst_pts[i].y;

        A.row(j)     << -x, -y, -1, 0, 0, 0, x * u, y * u, u;
        A.row(j + 1) << 0, 0, 0, -x, -y, -1, x * v, y * v, v;
    }

    Eigen::MatrixXd AtA = A.transpose() * A;
    Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> eig_solver(AtA);
    Eigen::VectorXd h = eig_solver.eigenvectors().col(0); // eigenvector with smallest eigenvalue

    Eigen::Matrix3d H;
    H << h(0), h(1), h(2),
         h(3), h(4), h(5),
         h(6), h(7), h(8);

    // Convert to OpenCV Mat
    cv::Mat H_cv(3, 3, CV_64F);
    cv::eigen2cv(H, H_cv);
    return H_cv;
}


std::vector<cv::Point2f> applyHomography(const cv::Mat& H, const std::vector<cv::Point2f>& src_pts) {
    std::vector<cv::Point2f> dst_pts;
    for (const auto& pt : src_pts) {
        cv::Mat pt_hom = (cv::Mat_<double>(3, 1) << pt.x, pt.y, 1.0);
        cv::Mat dst_hom = H * pt_hom;
        dst_pts.emplace_back(dst_hom.at<double>(0, 0) / dst_hom.at<double>(2, 0),
                             dst_hom.at<double>(1, 0) / dst_hom.at<double>(2, 0));
    }
    return dst_pts;
}

cv::Mat showCorrespondence(const cv::Mat& img1, const cv::Mat& img2,
                           const std::vector<cv::Point2f>& pts1,
                           const std::vector<cv::Point2f>& pts2) {
    int width = img1.cols + img2.cols;
    int height = std::max(img1.rows, img2.rows);
    cv::Mat result(height, width, CV_8UC3, cv::Scalar::all(0));

    // Place images side by side
    img1.copyTo(result(cv::Rect(0, 0, img1.cols, img1.rows)));
    img2.copyTo(result(cv::Rect(img1.cols, 0, img2.cols, img2.rows)));

    for (size_t i = 0; i < pts1.size(); ++i) {
        cv::Point2f pt1 = pts1[i];
        cv::Point2f pt2 = pts2[i] + cv::Point2f(img1.cols, 0); // shift pt2

        cv::line(result, pt1, pt2, cv::Scalar(0, 255, 0), 2);
    }

    return result;
}

std::vector<cv::Point2f> applyHomography(const cv::Mat& H, const std::vector<cv::Point2f>& src_pts) {
    std::vector<cv::Point2f> dst_pts;
    for (const auto& pt : src_pts) {
        cv::Mat pt_hom = (cv::Mat_<double>(3, 1) << pt.x, pt.y, 1.0);
        cv::Mat dst_hom = H * pt_hom;
        dst_pts.emplace_back(dst_hom.at<double>(0, 0) / dst_hom.at<double>(2, 0),
                             dst_hom.at<double>(1, 0) / dst_hom.at<double>(2, 0));
    }
    return dst_pts;
}

cv::Mat showCorrespondence(const cv::Mat& img1, const cv::Mat& img2,
                           const std::vector<cv::Point2f>& pts1,
                           const std::vector<cv::Point2f>& pts2) {
    int width = img1.cols + img2.cols;
    int height = std::max(img1.rows, img2.rows);
    cv::Mat result(height, width, CV_8UC3, cv::Scalar::all(0));

    // Place images side by side
    img1.copyTo(result(cv::Rect(0, 0, img1.cols, img1.rows)));
    img2.copyTo(result(cv::Rect(img1.cols, 0, img2.cols, img2.rows)));

    for (size_t i = 0; i < pts1.size(); ++i) {
        cv::Point2f pt1 = pts1[i];
        cv::Point2f pt2 = pts2[i] + cv::Point2f(img1.cols, 0); // shift pt2

        cv::line(result, pt1, pt2, cv::Scalar(0, 255, 0), 2);
    }

    return result;
}

std::pair<cv::Mat, cv::Mat> backwardWarpImg(const cv::Mat& src_img, const cv::Mat& destToSrc_H, const cv::Size& canvas_size) {
    cv::Mat dest_img(canvas_size, CV_32FC3, cv::Scalar::all(0));
    cv::Mat dest_mask(canvas_size, CV_8UC1, cv::Scalar::all(0));

    for (int y = 0; y < canvas_size.height; ++y) {
        for (int x = 0; x < canvas_size.width; ++x) {
            cv::Mat dest = (cv::Mat_<double>(3,1) << x, y, 1);
            cv::Mat src = destToSrc_H * dest;
            src /= src.at<double>(2, 0);
            int sx = static_cast<int>(src.at<double>(0, 0));
            int sy = static_cast<int>(src.at<double>(1, 0));

            if (sx >= 0 && sx < src_img.cols && sy >= 0 && sy < src_img.rows) {
                dest_img.at<cv::Vec3f>(y, x) = src_img.at<cv::Vec3f>(sy, sx);
                dest_mask.at<uchar>(y, x) = 255;
            }
        }
    }

    return {dest_mask, dest_img};
}
cv::Mat blendImagePair(const cv::Mat& img1, const cv::Mat& mask1, const cv::Mat& img2, const cv::Mat& mask2, const std::string& mode) {
    cv::Mat m1, m2;
    cv::threshold(mask1, m1, 0, 1, cv::THRESH_BINARY);
    cv::threshold(mask2, m2, 0, 1, cv::THRESH_BINARY);

    if (mode == "overlay") {
        cv::Mat result = img1.clone();
        img2.copyTo(result, m2);
        return result;
    }

    else if (mode == "blend") {
        cv::Mat dist1, dist2;
        cv::distanceTransform(255 - m1, dist1, cv::DIST_L2, 5);
        cv::distanceTransform(255 - m2, dist2, cv::DIST_L2, 5);

        cv::Mat mask_sum = dist1 + dist2;
        cv::Mat blended = (img1.mul(dist1 / mask_sum) + img2.mul(dist2 / mask_sum));
        return blended;
    }

    return img1;
}

std::pair<std::vector<int>, cv::Mat> runRANSAC(const std::vector<cv::Point2f>& src_pts,
                                               const std::vector<cv::Point2f>& dst_pts,
                                               int ransac_n, float eps) {
    std::vector<int> best_inliers;
    cv::Mat best_H;

    for (int i = 0; i < ransac_n; ++i) {
        std::vector<int> idx;
        while (idx.size() < 4) {
            int r = rand() % src_pts.size();
            if (std::find(idx.begin(), idx.end(), r) == idx.end()) idx.push_back(r);
        }

        std::vector<cv::Point2f> src_sel, dst_sel;
        for (int j : idx) {
            src_sel.push_back(src_pts[j]);
            dst_sel.push_back(dst_pts[j]);
        }

        cv::Mat H = computeHomography(src_sel, dst_sel);
        std::vector<cv::Point2f> dst_pred = applyHomography(H, src_pts);

        std::vector<int> inliers;
        for (size_t k = 0; k < dst_pts.size(); ++k) {
            float d = cv::norm(dst_pts[k] - dst_pred[k]);
            if (d < eps) inliers.push_back(k);
        }

        if (inliers.size() > best_inliers.size()) {
            best_inliers = inliers;
            best_H = H;
        }
    }

    return {best_inliers, best_H};
}

std::tuple<int, int, int, int> findCorners(const std::vector<cv::Point2f>& corners, const cv::Mat& img) {
    float min_x = std::min_element(corners.begin(), corners.end(), [](auto& a, auto& b){ return a.x < b.x; })->x;
    float min_y = std::min_element(corners.begin(), corners.end(), [](auto& a, auto& b){ return a.y < b.y; })->y;

    int top_x = (min_x < 0) ? static_cast<int>(-min_x) : 0;
    int top_y = (min_y < 0) ? static_cast<int>(-min_y) : 0;

    float max_x = std::max_element(corners.begin(), corners.end(), [](auto& a, auto& b){ return a.x < b.x; })->x;
    float max_y = std::max_element(corners.begin(), corners.end(), [](auto& a, auto& b){ return a.y < b.y; })->y;

    int max_width = std::max(static_cast<int>(max_x + top_x), img.cols + top_x);
    int max_height = std::max(static_cast<int>(max_y + top_y), img.rows + top_y);

    return {max_width, max_height, top_x, top_y};
}
